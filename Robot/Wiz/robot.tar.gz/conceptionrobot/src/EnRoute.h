
#ifndef ENROUTE_H
#define ENROUTE_H

#include <string>
#include "EtatRobot.h"
#include "Fige.h"

class EnRoute : public EtatRobot
{
protected:
    EnRoute ();
    virtual ~EnRoute ( );
public:
    void figer ( Robot* r );
    void tourner ( Robot* r, std::string direction );
};

#endif // ENROUTE_H

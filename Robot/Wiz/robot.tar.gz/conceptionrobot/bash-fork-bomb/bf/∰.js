function $(id) {
	return document.getElementById(id);
}

function $$(tag) {
	return document.getElementsByTagName(tag);	
}

var $body   = $$('body')[0],
	$srcDiv = $('src'),
	$out    = $('out'),
	src     = '++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++.>+.+++++++..+++.>++.<<+++++++++++++++.>.+++.------.--------.>+.>.',
	idx     = 0,
	idxSrc  = 0,
	map     = [],
	loop    = [];
						
for(var i = 0; i < 1337; ++i) {
	//if we follow the spec, it should be 30000
	map[i] = 0;
}

$body.className += 'js';

function changePointer() {
	/*mod = ;
	mod += '<span class="currChar">'
	mod += src[idxSrc];
	mod += '</span>';
	mod += src.substr(idxSrc + 1);
	$srcDiv.innerHMTML = mod;*/
	
	var beg = document.createTextNode(src.substr(0, idxSrc)),
		mid = document.createElement('span'),
		txt = document.createTextNode(src[idx]),
		end = document.createTextNode(src.substr(idxSrc + 1));
		
	mid.className = 'currChar';
	mid.appendChild(txt);
	
	$srcDiv.innerHTML = '';
	$srcDiv.appendChild(beg);
	$srcDiv.appendChild(mid);
	$srcDiv.appendChild(end);
}

function bf() {
	if(idxSrc >= src.length) {
		return;
	}
	
	changePointer();
	var curr = src[idxSrc];
		
	switch(curr) {
		case '+':
			++map[idx];
			++idxSrc;
			break;
			
		case '-':
			--map[idx];
			++idxSrc;
			break;
			
		case '>':
			++idx;
			++idxSrc;
			break;
		case '<':
			--idx;
			++idxSrc;
			break;
		case '.':
			var c = String.fromCharCode(map[idx]);
			if(c == '\n') {
				c = '<br />';
			}
			else if(c == ' ') {
				c = '&nbsp;'
			}
			$out.innerHTML += c;
			++idxSrc;
			break;
		case ',':
			var s;
			while(!s) { prompt('WTF?', ''); }
			map[idx] = s[0];
			++idxSrc;
			break;
		case '[':
			if(map[idx] != 0) {
				loop.push(idxSrc);
				++idxSrc;
			}
			
			else {
				var counter = 1;
				
				while(counter != 0) {
					++idxSrc;
					
					if(src[idxSrc] == '[') { ++counter; }
					else if(src[idxSrc] == ']') { --counter;}
				}
				++idxSrc;
			}
			break;
			
		case ']':
			if(map[idx] != 0) {
				idxSrc = loop[loop.length - 1];
				loop.pop();
			}
			
			else {
				++idxSrc;
				loop.pop();
			}
			break;
			
		default: //comment
			++idxSrc;
			break;
	}
	
	setTimeout(bf, 1);
}

$srcDiv.innerHTML = src;
bf();

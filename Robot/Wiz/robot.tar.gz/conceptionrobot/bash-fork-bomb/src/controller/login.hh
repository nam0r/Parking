#ifndef __CONTROLLER_LOGIN__
#define __CONTROLLER_LOGIN__

#include "../request.hh"

class ControllerLogin
{
public:
    static void actionLogin(Request& r);
};

#endif /*__CONTROLLER_LOGIN__*/

#include "login.hh"

void ControllerLogin::actionLogin(Request& r)
{
    r.out << "Status: 200" << endl;
    r.out << "Content-type: text/html" << endl;
    r.out << endl;

    r.out << "Not implemented" << endl;
}

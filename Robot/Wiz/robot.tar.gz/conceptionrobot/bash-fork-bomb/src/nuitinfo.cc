#include "application.hh"

#include "controller/login.hh"

class NuitInfo : public Application
{
public:
    NuitInfo()
    {
        route404(action404);
        route("", NuitInfo::actionIndex);
        route("b", NuitInfo::actionB);

        route("login", ControllerLogin::actionLogin);
        /*
        route("login/login", ControllerLogin::actionLogin);
        route("login/register", ControllerLogin::actionRegister);
        route("login/logout", ControllerLogin::actionLogout);
        //route("user/:username:", controllerUser);
        */
    }

    static void actionIndex(Request& r)
    {
        r.out << "Status: 200" << endl;
        r.out << "Content-type: text/html" << endl;
        r.out << endl;

        r.out << "Hello world from " << r.getenv("REQUEST_URI") << endl;
    }

    static void action404(Request& r)
    {
        r.out << "Status: 404 Not Found" << endl;
        r.out << endl;

        r.out << "L'adresse " << r.getenv("REQUEST_URI") << " n'est pas ici. Allez voir ailleurs si elle y est." << endl;
    }

    static void actionB(Request &r)
    {
        srand(time(NULL));

        int locs[] = {1065, 1384, 360, 281, 749, 1488, 1263, 1204, 1005, 469, 1451, 746, 586, 1207, 1118, 1012, 608, 324, 180, 468, 709, 1113, 1111, 403, 1922, 1397, 285, 5, 6, 8, 16, 18, 21, 24, 31, 36, 56, 59, 60, 63, 64, 79, 83, 119, 133, 846, 2035, 1363};
        int i = rand() % (sizeof(locs) / sizeof(locs[0]));
        r.out << "Status: 200" << endl;
        r.out << "Location: http://z0r.de/" << locs[i] << endl;
        r.out << endl;
    }
};

int main(int argc, char* argv[])
{
    NuitInfo mess;
    mess.start();

    return 0;
}

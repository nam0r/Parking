#include "request.hh"

Request::Request(FCGX_Request& fr)
     : frequest(fr)
{
    in.attach(frequest.in);
    out.attach(frequest.out);
    err.attach(frequest.err);

    for(int i = 0; frequest.envp[i]; i++)
    {
        string line = frequest.envp[i];
        size_t pos = line.find('=');
        if(pos != string::npos)
        {
            string name = line.substr(0, pos);
            string value = line.substr(pos + 1);
            env[name] = value;
        }
    }
}

string Request::getenv(string name)
{
    return env[name];
}

void Request::set(string name, string value)
{
    args[name] = value;
}

string Request::get(string name)
{
    return args[name];
}

#include <stdlib.h>
#include <fcgio.h>
#include <sstream>
#include <pthread.h>
#include <iostream>

#include "application.hh"

Application::Application()
{
}

Application::~Application()
{
}

void* Application::cbRun(void* arg)
{
    Application* app = static_cast<Application*>(arg);
    app->run();
    return NULL;
}

void Application::run()
{
    FCGX_Request frequest;
    FCGX_InitRequest(&frequest, 0, 0);

    while(FCGX_Accept_r(&frequest) >= 0)
    {
        Request r(frequest);
        dispatcher.dispatch(r);
        FCGX_Finish();
    }
}

void Application::start()
{
    int nPools = 2;

    if(FCGX_Init() != 0)
    {
        cerr << "FCGX_Init failed" << endl;
        exit(1);
    }

    if(getenv("THREADS"))
        istringstream(getenv("THREADS")) >> nPools;

    if(!FCGX_IsCGI())
    {
        pthread_t threads[nPools];
        
        for(int i = 0; i < nPools; i++)
            pthread_create(&threads[i], NULL, cbRun, (void*)this);

        for(int i = 0; i < nPools; i++)
            pthread_join(threads[i], NULL);
    }
    else
    {
        run();
    }
}

void Application::route(string url, ActionRoute route)
{
    dispatcher.add(url, route);
}

void Application::route404(ActionRoute route)
{
    dispatcher.set404(route);
}

#ifndef __CONTROLLER__
#define __CONTROLLER__

#include <boost/regex.hpp>

#include "request.hh"

using namespace std;
using namespace boost;

typedef void(*ActionRoute)(Request&);

struct Route
{
    string pattern;
    vector<string> args;
    regex ex;
    ActionRoute route;
};

class Dispatcher
{
private:
    vector<Route> routes;
    ActionRoute route404;
public:
    void dispatch(Request& r);
    void add(string uri, ActionRoute route);
    void set404(ActionRoute);
};

#endif /*__CONTROLLER__*/

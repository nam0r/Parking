#ifndef __DATABASE__
#define __DATABASE__

#include <vector>
#include <string>

class User;

class Database {
	public:
		vector<User> getUsers() = 0;
		bool connect(string login, string mdp) = 0;
		bool signIn(string login, string email, string mdp) = 0;
		User getProfile(string login) = 0;
}

#endif

#ifndef __REQUEST__
#define __REQUEST__

#include <stdlib.h>
#include <iostream>
#include <fcgio.h>
#include <tr1/unordered_map>
#include <map>

using namespace std;
using namespace tr1;

class Request
{
private:
    FCGX_Request& frequest;
    unordered_map<string, string> env;
    map<string, string> args;
public:
    fcgi_istream in;
    fcgi_ostream out;
    fcgi_ostream err;

    Request(FCGX_Request& fr);
    /**
        Useful variables can be QUERY_STRING, HTTP_HOST, HTTP_COOKIE, REMOTE_ADDR, REQUEST_METHOD, REQUEST_URI
    */
    string getenv(string name);
    void set(string name, string value);
    string get(string name);
};

#endif /*__REQUEST__*/

#ifndef __PAGE__
#define __PAGE__

#include <iostream>
/*
 * Proposition de début de classe Page
 * Rien de définitif, je suis ouvert à toute remarque
 */
class Page {
	private:
		Database* base;
	public:
		std::ostream& operator>> (std::ostream& o);
		std::string show(User u); // fonction pour récup le code de la page, vue par l'utilisateur u
};

#endif


#ifndef __APPLICATION__
#define __APPLICATION__

#include "dispatcher.hh"

class Application
{
private:
    Dispatcher dispatcher;
    static void* cbRun(void*);
    void run();
public:
    Application();
    virtual ~Application();

    void route(string, ActionRoute);
    void route404(ActionRoute);
    void start();
};

#endif /*__APPLICATION__*/

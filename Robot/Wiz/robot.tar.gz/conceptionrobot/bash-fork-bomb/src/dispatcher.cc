#include "dispatcher.hh"

void Dispatcher::add(string url, void (*fct)(Request& r))
{
    Route route;

    route.route = fct;

    cmatch res;
    regex rx(":([^:]+):");
    for(const char *where = url.c_str(); regex_search(where, res, rx); where = res.suffix().first)
        route.args.push_back(res[1]);

    string strpattern = url;
    for(vector<string>::const_iterator it = route.args.begin(); it != route.args.end(); it++)
        strpattern = regex_replace(strpattern, regex(":" + (*it) + ":"), "([^/]+)");
    route.ex = regex("[/]*" + strpattern + "[/]*");

    routes.push_back(route);
}

void Dispatcher::dispatch(Request& r)
{
    string url = r.getenv("REQUEST_URI");

    for(vector<Route>::const_iterator it = routes.begin(); it != routes.end(); it++)
    {
        cmatch matches;
        if(regex_match(url.c_str(), matches, it->ex))
        {
            for(int i = 1; i < it->args.size() + 1; i++)
                r.set(it->args[i - 1], matches[i]);
            it->route(r);
            return;
        }
    }

    route404(r);
}

void Dispatcher::set404(ActionRoute route)
{
    route404 = route;
}

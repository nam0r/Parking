/* This program is free software. It comes without any warranty, to
 * the extent permitted by applicable law. You can redistribute it
 * and/or modify it under the terms of the Do What The Fuck You Want
 * To Public License, Version 2, as published by Sam Hocevar. See
 * http://sam.zoy.org/wtfpl/COPYING for more details. */

/*
 * SHA-256.h
 *
 *  Created on: 5 juin 2010
 *  Author: Alexis Daboville <alexis.daboville@gmail.com>
 *  References:
 *  http://en.wikipedia.org/wiki/SHA-2#SHA-256_.28a_SHA-2_variant.29_pseudocode
 *  http://docs.google.com/viewer?url=http://csrc.nist.gov/publications/fips/fips180-2/fips180-2.pdf	
 */

#ifndef SHA256_H_
#define SHA256_H_

#include <sstream>
#include <stdint.h>
#include <string>
#include <vector>

std::string SHA256(std::string str);

#endif /* SHA256_H_ */

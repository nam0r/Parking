#include "Position.h"

// Constructors/Destructors
//  

Position::Position ( ) {
initAttributes();
}

Position::~Position ( ) { }

//  
// Methods
//  


// Accessor methods
//  


// Other methods
//  


#ifndef ETATROBOTENCHARGEFACEOBSTACLE_H
#define ETATROBOTENCHARGEFACEOBSTACLE_H
#include "EtatRobot.h"
#include "EnRoute.h"

#include <string>
class EtatRobotEnChargeFaceObstacle : public EtatRobot, public EnRoute
{
public:

    // Constructors/Destructors
    //  


    /**
     * Empty Constructor
     */
    EtatRobotEnChargeFaceObstacle ( );

    /**
     * Empty Destructor
     */
    virtual ~EtatRobotEnChargeFaceObstacle ( );



    /**
     * @return int
     */
    int peser ( );


    /**
     */
    void poser ( );

protected:

public:

protected:

public:

protected:


private:

public:

private:

public:

private:



};

#endif // ETATROBOTENCHARGEFACEOBSTACLE_H

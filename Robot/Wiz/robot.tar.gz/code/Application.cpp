#include "Robot.h"

int main(int argc, char *argv[])
{
    Robot robot;

    return 0;
}
